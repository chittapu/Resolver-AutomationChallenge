package resolver.QA.Pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AutomationChallengesPage {
	WebDriver driver;
	public AutomationChallengesPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(id = "inputEmail")
	WebElement emailId;
	public WebElement getemailId() {
		return emailId;
	}
	@FindBy(id = "inputPassword")
	WebElement password;
	public WebElement getpassword() {
		return password;
	}
	@FindBy(xpath = "//*[text()='Sign in']")
	WebElement loginBtn;
	public WebElement getloginBtn() {
		return loginBtn;
	}
	@FindBy(xpath = "//*[@id=\"test-2-div\"]/ul/li")
	List<WebElement> test2Check;
	public List<WebElement> gettest2Check() {
		return test2Check;
	}
	@FindBy(id = "dropdownMenuButton")
	WebElement dropdown;
	public WebElement getdropdown() {
		return dropdown;
	}
	@FindBy(xpath = "//a[text()='Option 3']")
	WebElement option3;
	public WebElement getoption3() {
		return option3;
	}
	@FindBy(xpath = "(//*[text()='Button'])[1]")
	WebElement btn1;
	public WebElement getbtn1() {
		return btn1;
	}
	@FindBy(xpath = "(//*[text()='Button'])[2]")
	WebElement btn2;
	public WebElement getbtn2() {
		return btn2;
	}
	@FindBy(xpath = "//*[@id='test5-button']")
	WebElement btnCheck;
	public WebElement getbtnCheck() {
		return btnCheck;
	}
	@FindBy(id = "test5-alert")
	WebElement alertMessage;
	public WebElement getalertMessage() {
		return alertMessage;
	}
}
