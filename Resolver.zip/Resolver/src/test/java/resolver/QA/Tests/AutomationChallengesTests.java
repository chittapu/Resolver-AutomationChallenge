package resolver.QA.Tests;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.checkerframework.checker.units.qual.t;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import resolver.QA.Base.Base;

public class AutomationChallengesTests extends Base{
	@Test(priority = 1)
	public void test1() {
		Assert.assertEquals(page.getemailId().isDisplayed(),true);
		Assert.assertEquals(page.getpassword().isDisplayed(),true);
		Assert.assertEquals( page.getpassword().isDisplayed(),true);
		page.getemailId().sendKeys("myname@resolver.com");
		page.getpassword().sendKeys("checkpassword");
		//page.getloginBtn().click();
		//System.out.println("Test 1 pass");
	}
	@Test(priority = 2)
	public void test2() {
		
		List<WebElement> list=page.gettest2Check();
		
		int count=0;
		for(int i=1;i<=list.size();i++) {
			//for countting list
			count++;
			//to validate list
			if(i==2) {
				String actual=driver.findElement(By.xpath("//div[@id='test-2-div']//li["+i+"]")).getText();
				String expected="List Item 2";
				
					Assert.assertTrue(actual.contains(expected));
					Reporter.log("assert pass text matches of list");
					//to check badge
					Assert.assertEquals(driver.findElement(By.xpath("(//*[@class='badge badge-pill badge-primary'])["+i+"]")).getText(), "6");
					Reporter.log("assert pass text matches for badge");
				//Assert.assertEquals(actual,expected);
					
				
			}
		}
		//to check list-count match
		Assert.assertEquals(count,3);
		
		
	}
	@Test(priority = 3)
	public void test3() throws InterruptedException {
		Assert.assertEquals(page.getdropdown().getText(),"Option 1");
		act.click(page.getdropdown()).click(page.getoption3()).perform();
		Thread.sleep(5000);
	}
	@Test(priority = 4)
	public void test4() {
		Assert.assertEquals(page.getbtn1().isEnabled(), true);
		System.err.println("Buttom1 Enabled");
		Assert.assertEquals(page.getbtn2().isEnabled(), false);
		System.err.println("Buttom2 Disabled");
	}
	@Test(priority = 5)
	public void test5() {
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.visibilityOf(page.getbtnCheck()));
		page.getbtnCheck().click();
		Assert.assertEquals(page.getalertMessage().getText(), "You clicked a button!");
		Assert.assertEquals(page.getbtnCheck().isEnabled(), false);
	}
	public String gettableData(int tr,int td) {
		String expected=driver.findElement(By.xpath("//*[@id='test-6-div']/div/table//tbody//tr["+tr+"]/td["+td+"]")).getText();
		return expected;
	}
	@Test(priority = 6)
	public void test6() {
		int tr=3;
		int td=3;
		Assert.assertEquals(gettableData(tr, td), "Ventosanzap"); ;
		
	}
	

}
