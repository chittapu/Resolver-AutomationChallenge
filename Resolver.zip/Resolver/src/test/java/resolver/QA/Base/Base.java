package resolver.QA.Base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.xml.internal.TestNamesMatcher;

import io.github.bonigarcia.wdm.WebDriverManager;
import resolver.QA.Pages.AutomationChallengesPage;
import resolver.QA.Tests.AutomationChallengesTests;

public class Base {
	public WebDriver driver;
	public AutomationChallengesPage page;
	public Select sle;
	public Actions act;
	public WebDriverWait wait;
	@BeforeMethod
	public void setUp() {
		//WebDriverManager.chromedriver().setup();
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Resources\\drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(System.getProperty("user.dir")+"/AutomationChallenge_2022/QE-index.html");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		page=new AutomationChallengesPage(driver);
		act=new Actions(driver);
	}
	@AfterMethod
	public void tearDown() {
		Reporter.log("PASS");
		driver.close();
	}

}
